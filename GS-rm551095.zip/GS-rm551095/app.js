const express = require('express'); 
const app = express(); 
const port = 8090; 

const alunos = [{ id:1, nome:"Gabriel" },{ id:2, nome:"Montez" }, ,{ id:3, nome:"Passananti" }];
 
app.get('/', (req, res) => { 
  res.send('GS-CloudDeveloper'); 
}); 

app.get('/alunos', (req, res) => { 
  res.json(alunos);
}); 

app.listen(port, () => { 
  console.log(`App running on port ${port}`); 
});